// To parse this JSON data, do
//
//     final productModels = productModelsFromJson(jsonString);

import 'dart:convert';

ProductModels productModelsFromJson(String str) =>
    ProductModels.fromJson(json.decode(str));

String productModelsToJson(ProductModels data) => json.encode(data.toJson());

class Product {
  List<ProductModels> items = [];

  Product();

  Product.fromJsonList(jsonList) {
    if (jsonList == null) {
      return;
    } else {
      jsonList.forEach((id, prod) {
        final producto = ProductModels.fromJson(prod);
        items.add(producto);
      });
    }
  }
}

class ProductModels {
  final String? id;
  final String? titulo;
  final int? valor;
  final bool? disponible;

  ProductModels({
    this.id,
    this.titulo,
    this.valor,
    this.disponible,
  });

  factory ProductModels.fromJson(Map<String, dynamic> json) => ProductModels(
        id: json["id"],
        titulo: json["titulo"],
        valor: json["valor"],
        disponible: json["disponible"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "titulo": titulo,
        "valor": valor,
        "disponible": disponible,
      };
}
