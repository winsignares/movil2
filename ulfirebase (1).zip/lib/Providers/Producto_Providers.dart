import 'dart:convert';

import 'package:ulfirebase/Models/ProductModels.dart';
import 'package:http/http.dart' as http;

class ProductoProvider {
  final String _url = 'https://ulmovil2-default-rtdb.firebaseio.com/';

  Future<bool> crearproductos(ProductModels producto) async {
    try {
      final url = '$_url/Productos.json';
      final resp = await http.post(
        Uri.parse(url),
        body: productModelsToJson(producto),
      );
      if (resp.statusCode == 200) {
        return true;
      } else {
        throw Exception('ocurrio algo ${resp.statusCode}');
      }
    } catch (e) {
      print(e);
      return false;
    }
  }

  Future<List<ProductModels>> getproducto() async {
    final url = '$_url/Productos.json';
    final resp = await http.get(Uri.parse(url));
    try {
      if (resp.statusCode == 200) {
        String body = utf8.decode(resp.bodyBytes);
        final jsonData = jsonDecode(body);
        final productos = Product.fromJsonList(jsonData);
        return productos.items;
      } else {
        throw Exception('ocurrio algo ${resp.statusCode}');
      }
    } catch (e) {
      print(e);
      throw Exception('ocurrio algo ${e.toString()}');
    }
  }

  Future<bool> updateproductos(ProductModels producto) async {
    try {
      final url = '$_url/Productos/${producto.id}.json';
      final resp = await http.put(
        Uri.parse(url),
        body: productModelsToJson(producto),
      );
      if (resp.statusCode == 200) {
        return true;
      } else {
        throw Exception('ocurrio algo ${resp.statusCode}');
      }
    } catch (e) {
      print(e);
      return false;
    }
  }

  Future<int> deleteproductos(String id) async {
    try {
      final url = '$_url/Productos/$id.json';
      final resp = await http.delete(Uri.parse(url));
      if (resp.statusCode == 200) {
        return 1;
      } else {
        throw Exception('ocurrio algo ${resp.statusCode}');
      }
    } catch (e) {
      print(e);
      return 0;
    }
  }
}
